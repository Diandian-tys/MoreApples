import { world, system } from "@minecraft/server";

const APPLE_EFFECTS = {
  "more_apples:swift_apple": [
    {
      "id": "speed",
      "amplifier": 1,
      "duration": 45
    }
  ],
  "more_apples:haste_apple": [
    {
      "id": "haste",
      "amplifier": 1,
      "duration": 60
    }
  ],
  "more_apples:strength_apple": [
    {
      "id": "strength",
      "amplifier": 1,
      "duration": 40
    }
  ],
  "more_apples:regen_apple": [
    {
      "id": "regeneration",
      "amplifier": 1,
      "duration": 15
    }
  ],
  "more_apples:resist_apple": [
    {
      "id": "resistance",
      "amplifier": 0,
      "duration": 50
    }
  ],
  "more_apples:jump_apple": [
    {
      "id": "jump_boost",
      "amplifier": 1,
      "duration": 40
    }
  ],
  "more_apples:night_apple": [
    {
      "id": "night_vision",
      "amplifier": 0,
      "duration": 90
    }
  ],
  "more_apples:fireproof_apple": [
    {
      "id": "fire_resistance",
      "amplifier": 0,
      "duration": 60
    }
  ],
  "more_apples:aqua_apple": [
    {
      "id": "water_breathing",
      "amplifier": 0,
      "duration": 75
    }
  ],
  "more_apples:absorb_apple": [
    {
      "id": "absorption",
      "amplifier": 1,
      "duration": 60
    }
  ],
  "more_apples:saturation_apple": [
    {
      "id": "saturation",
      "amplifier": 0,
      "duration": 10
    }
  ],
  "more_apples:health_apple": [
    {
      "id": "instant_health",
      "amplifier": 1,
      "duration": 1
    }
  ],
  "more_apples:luck_apple": [
    {
      "id": "luck",
      "amplifier": 0,
      "duration": 120
    }
  ],
  "more_apples:dolphin_apple": [
    {
      "id": "dolphins_grace",
      "amplifier": 0,
      "duration": 40
    }
  ],
  "more_apples:conduit_apple": [
    {
      "id": "conduit_power",
      "amplifier": 0,
      "duration": 50
    }
  ],
  "more_apples:hero_apple": [
    {
      "id": "village_hero",
      "amplifier": 0,
      "duration": 90
    }
  ],
  "more_apples:glow_apple": [
    {
      "id": "glowing",
      "amplifier": 0,
      "duration": 60
    }
  ],
  "more_apples:slow_falling_apple": [
    {
      "id": "slow_falling",
      "amplifier": 0,
      "duration": 45
    }
  ],
  "more_apples:phantom_apple": [
    {
      "id": "slow_falling",
      "amplifier": 0,
      "duration": 30
    },
    {
      "id": "weakness",
      "amplifier": 0,
      "duration": 20
    }
  ],
  "more_apples:levitation_apple": [
    {
      "id": "levitation",
      "amplifier": 0,
      "duration": 8
    },
    {
      "id": "slow_falling",
      "amplifier": 0,
      "duration": 15
    }
  ],
  "more_apples:invisibility_apple": [
    {
      "id": "invisibility",
      "amplifier": 0,
      "duration": 25
    }
  ],
  "more_apples:chorus_apple": [
    {
      "id": "levitation",
      "amplifier": 0,
      "duration": 5
    },
    {
      "id": "nausea",
      "amplifier": 0,
      "duration": 8
    }
  ],
  "more_apples:magma_apple": [
    {
      "id": "fire_resistance",
      "amplifier": 0,
      "duration": 40
    },
    {
      "id": "strength",
      "amplifier": 0,
      "duration": 20
    }
  ],
  "more_apples:ice_apple": [
    {
      "id": "slowness",
      "amplifier": 0,
      "duration": 15
    },
    {
      "id": "resistance",
      "amplifier": 0,
      "duration": 30
    }
  ],
  "more_apples:honey_apple": [
    {
      "id": "regeneration",
      "amplifier": 0,
      "duration": 8
    },
    {
      "id": "saturation",
      "amplifier": 0,
      "duration": 5
    }
  ],
  "more_apples:prismarine_apple": [
    {
      "id": "water_breathing",
      "amplifier": 0,
      "duration": 60
    },
    {
      "id": "night_vision",
      "amplifier": 0,
      "duration": 40
    }
  ],
  "more_apples:netherite_apple": [
    {
      "id": "resistance",
      "amplifier": 1,
      "duration": 60
    },
    {
      "id": "strength",
      "amplifier": 1,
      "duration": 30
    },
    {
      "id": "fire_resistance",
      "amplifier": 0,
      "duration": 60
    }
  ],
  "more_apples:end_apple": [
    {
      "id": "slow_falling",
      "amplifier": 0,
      "duration": 40
    },
    {
      "id": "night_vision",
      "amplifier": 0,
      "duration": 50
    }
  ],
  "more_apples:amethyst_apple": [
    {
      "id": "regeneration",
      "amplifier": 0,
      "duration": 12
    },
    {
      "id": "luck",
      "amplifier": 0,
      "duration": 60
    }
  ],
  "more_apples:emerald_apple": [
    {
      "id": "village_hero",
      "amplifier": 0,
      "duration": 60
    },
    {
      "id": "luck",
      "amplifier": 0,
      "duration": 40
    }
  ],
  "more_apples:poison_apple": [
    {
      "id": "poison",
      "amplifier": 0,
      "duration": 12
    }
  ],
  "more_apples:wither_apple": [
    {
      "id": "wither",
      "amplifier": 0,
      "duration": 8
    }
  ],
  "more_apples:blind_apple": [
    {
      "id": "blindness",
      "amplifier": 0,
      "duration": 15
    }
  ],
  "more_apples:nausea_apple": [
    {
      "id": "nausea",
      "amplifier": 0,
      "duration": 20
    }
  ],
  "more_apples:hunger_apple": [
    {
      "id": "hunger",
      "amplifier": 1,
      "duration": 25
    }
  ],
  "more_apples:weak_apple": [
    {
      "id": "weakness",
      "amplifier": 0,
      "duration": 40
    }
  ],
  "more_apples:slow_apple": [
    {
      "id": "slowness",
      "amplifier": 1,
      "duration": 30
    }
  ],
  "more_apples:fatigue_apple": [
    {
      "id": "mining_fatigue",
      "amplifier": 0,
      "duration": 45
    }
  ],
  "more_apples:toxic_apple": [
    {
      "id": "poison",
      "amplifier": 0,
      "duration": 10
    },
    {
      "id": "hunger",
      "amplifier": 0,
      "duration": 15
    }
  ],
  "more_apples:cursed_apple": [
    {
      "id": "wither",
      "amplifier": 0,
      "duration": 6
    },
    {
      "id": "blindness",
      "amplifier": 0,
      "duration": 10
    },
    {
      "id": "slowness",
      "amplifier": 0,
      "duration": 15
    }
  ],
  "more_apples:rotten_apple": [
    {
      "id": "hunger",
      "amplifier": 1,
      "duration": 20
    },
    {
      "id": "nausea",
      "amplifier": 0,
      "duration": 12
    }
  ],
  "more_apples:void_apple": [
    {
      "id": "levitation",
      "amplifier": 0,
      "duration": 12
    },
    {
      "id": "blindness",
      "amplifier": 0,
      "duration": 8
    }
  ],
  "more_apples:crimson_apple": [
    {
      "id": "strength",
      "amplifier": 0,
      "duration": 25
    },
    {
      "id": "fire_resistance",
      "amplifier": 0,
      "duration": 20
    }
  ],
  "more_apples:azure_apple": [
    {
      "id": "speed",
      "amplifier": 0,
      "duration": 30
    },
    {
      "id": "water_breathing",
      "amplifier": 0,
      "duration": 30
    }
  ],
  "more_apples:goldenrod_apple": [
    {
      "id": "regeneration",
      "amplifier": 0,
      "duration": 10
    },
    {
      "id": "absorption",
      "amplifier": 0,
      "duration": 30
    }
  ],
  "more_apples:coral_apple": [
    {
      "id": "water_breathing",
      "amplifier": 0,
      "duration": 40
    },
    {
      "id": "dolphins_grace",
      "amplifier": 0,
      "duration": 25
    }
  ],
  "more_apples:obsidian_apple": [
    {
      "id": "resistance",
      "amplifier": 1,
      "duration": 50
    },
    {
      "id": "slowness",
      "amplifier": 0,
      "duration": 15
    }
  ],
  "more_apples:cactus_apple": [
    {
      "id": "poison",
      "amplifier": 0,
      "duration": 6
    },
    {
      "id": "speed",
      "amplifier": 0,
      "duration": 20
    }
  ],
  "more_apples:chorus_fruit_apple": [
    {
      "id": "levitation",
      "amplifier": 0,
      "duration": 4
    }
  ],
  "more_apples:sweet_apple": [
    {
      "id": "saturation",
      "amplifier": 0,
      "duration": 8
    },
    {
      "id": "regeneration",
      "amplifier": 0,
      "duration": 6
    }
  ],
  "more_apples:bitter_apple": [
    {
      "id": "nausea",
      "amplifier": 0,
      "duration": 15
    },
    {
      "id": "weakness",
      "amplifier": 0,
      "duration": 20
    }
  ],
  "more_apples:spark_apple": [
    {
      "id": "speed",
      "amplifier": 1,
      "duration": 20
    },
    {
      "id": "nausea",
      "amplifier": 0,
      "duration": 8
    }
  ],
  "more_apples:shadow_apple": [
    {
      "id": "invisibility",
      "amplifier": 0,
      "duration": 20
    },
    {
      "id": "blindness",
      "amplifier": 0,
      "duration": 5
    }
  ],
  "more_apples:solar_apple": [
    {
      "id": "night_vision",
      "amplifier": 0,
      "duration": 60
    },
    {
      "id": "fire_resistance",
      "amplifier": 0,
      "duration": 30
    }
  ],
  "more_apples:lunar_apple": [
    {
      "id": "night_vision",
      "amplifier": 0,
      "duration": 80
    },
    {
      "id": "slow_falling",
      "amplifier": 0,
      "duration": 30
    }
  ],
  "more_apples:storm_apple": [
    {
      "id": "speed",
      "amplifier": 1,
      "duration": 25
    },
    {
      "id": "jump_boost",
      "amplifier": 0,
      "duration": 20
    }
  ],
  "more_apples:earth_apple": [
    {
      "id": "resistance",
      "amplifier": 0,
      "duration": 40
    },
    {
      "id": "haste",
      "amplifier": 0,
      "duration": 30
    }
  ],
  "more_apples:wind_apple": [
    {
      "id": "speed",
      "amplifier": 0,
      "duration": 35
    },
    {
      "id": "jump_boost",
      "amplifier": 0,
      "duration": 25
    }
  ],
  "more_apples:frost_apple": [
    {
      "id": "slowness",
      "amplifier": 0,
      "duration": 20
    },
    {
      "id": "resistance",
      "amplifier": 0,
      "duration": 35
    }
  ],
  "more_apples:blaze_apple": [
    {
      "id": "fire_resistance",
      "amplifier": 0,
      "duration": 50
    },
    {
      "id": "strength",
      "amplifier": 0,
      "duration": 20
    }
  ],
  "more_apples:warden_apple": [
    {
      "id": "darkness",
      "amplifier": 0,
      "duration": 15
    },
    {
      "id": "strength",
      "amplifier": 1,
      "duration": 15
    }
  ],
  "more_apples:sculk_apple": [
    {
      "id": "darkness",
      "amplifier": 0,
      "duration": 12
    },
    {
      "id": "speed",
      "amplifier": 0,
      "duration": 20
    }
  ]
};

world.afterEvents.itemCompleteUse.subscribe((event) => {
    const player = event.source;
    const item = event.itemStack;
    if (!player || !item) return;

    const effects = APPLE_EFFECTS[item.typeId];
    if (!effects) return;

    for (const e of effects) {
        try {
            player.addEffect(e.id, e.duration * 20, {
                amplifier: e.amplifier,
                showParticles: true
            });
        } catch (err) {
            // Some effects may not exist in older versions
        }
    }
});
